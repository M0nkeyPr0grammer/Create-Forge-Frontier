Icons made by Yankonnin: https://www.fiverr.com/yankonnin?source=inbox, Chernobyl and BellArts
Art of the pack.png icon made by Zenokim: https://linktr.ee/zenokim