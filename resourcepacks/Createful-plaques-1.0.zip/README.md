# Createful-Plaques
This resource pack replaces the default look of Advancement Plaques Mod by Grend_G with a heavily inspired create style
